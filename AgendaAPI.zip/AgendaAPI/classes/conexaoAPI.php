<?php
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => 'http://localhost/apis/rest_basico.php',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'GET',
    ));
  
    $output = curl_exec($curl);
  
    curl_close($curl);
  
    $decoded = json_decode($output);
     
    ?>