<?php
include 'classes/contatos.class.php';
$contato = new Contatos();

if(!empty($_GET['idContato'])){
    $idContato = $_GET['idContato'];
    $contato->excluir($idContato);
    header("Location: /AgendaSenac");

}
else{
    echo '<script type="text/javascript">alert("Erro ao excluir contato!");</script>';
    header("Location: /AgendaSenac");
}