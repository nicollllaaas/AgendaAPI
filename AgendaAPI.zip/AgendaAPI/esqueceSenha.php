<?php
include 'inc/header.inc.php';
include 'classes/usuarios.class.php';
 
    $email = $_POST['email'];
 
    $user = new Usuarios();
 
    $teste = $user->esqueceSenha($email);
 
    $id = $teste['id'];
 
    $info = $user->buscar($id);
?>


<h1 class="text-center" style="margin-bottom: 120px">ALTERE SUA SENHA</h1>
<div class="row justify-content-center">
    <form method="POST" action="esqueceSenhaSubmit.php">
    <input type="hidden" name="id" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['id'] ?>" />
    <input type="hidden" name="nome" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['nome'] ?>" />
    <input type="hidden" name="email" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['email'] ?>" />
    <input type="hidden" name="permissoes" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['permissoes'] ?>" />
        Senha: <br>
        <input type="password" name="senha" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" /><br><br>

        <input type="submit" class="btn btn-success" style="margin-bottom: 150px" name="btCadastrar" value="Alterar" />
    </form>
</div style="margin-bottom: 100px">

<?php
include 'inc/footer.inc.php';
?>