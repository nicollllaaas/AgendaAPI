<?php
include 'classes/contatos.class.php';
include 'classes/usuarios.class.php';
include 'inc/header.inc.php';
require 'classes/conexaoAPI.php';
session_start();
if (!isset($_SESSION['Logado'])) {
    header("Location: login.php");
    exit;
}
$usuarios = new Usuarios();
$usuarios->setUsuario($_SESSION['Logado']);
$contato = new Contatos();
?>
<h1 style="text-align: center;">Seus Contatos</h1>
<hr>
<button class="btn btn-danger"><a href="logout.php" class="text-light">SAIR</a></button>
<?php if ($usuarios->temPermissoes('add')) : ?><button class="btn btn-success d-grid "><a href="adicionarSubmit.php" class="text-light">ADICIONAR CONTATO</a></button><?php endif; ?>
<?php if ($usuarios->temPermissoes('super')) : ?><button class="btn btn-success d-grid ml-1 "><a href="indexUsuarios.php" class="text-light mr-1">USUARIOS</a></button><?php endif; ?>
<br><br>

<table class="table table-dark table-striped" style="margin-bottom: 250px, width=90%;">
    <tr>
        <th>idContato</th>
        <th>Nome</th>
        <th>Email</th>
        <th>telefone</th>
        <th>cidade</th>
        <th>rua</th>
        <th>bairro</th>
        <th>numero</th>
        <th>cep</th>
        <th>Profissao</th>
        <th>Dt Nasc</th>

    </tr>

    <tbody>
        <?php
        foreach ($decoded as $x) :
        ?>
            <tr>

                <td> <?php echo $x->idContato ?> </td>
                <td> <?php echo $x->nome ?> </td>
                <td> <?php echo $x->email ?> </td>
                <td> <?php echo $x->telefone ?> </td>
                <td> <?php echo $x->cidade ?> </td>
                <td> <?php echo $x->rua ?> </td>
                <td> <?php echo $x->bairro ?> </td>
                <td> <?php echo $x->numero ?> </td>
                <td> <?php echo $x->cep ?> </td>
                <td> <?php echo $x->profissao ?> </td>
                <td> <?php echo $x->dt_nasc ?> </td>


                <td class=" d-flex justify-content-center">
                    <?php if ($usuarios->temPermissoes('edit')) : ?><button class="btn btn-success btn-sm mr-1"> <a class="text-light" href="editarContato.php?idContato=<?php echo $x->idContato ?>">EDITAR</a><?php endif; ?></button> |

                        <?php if ($usuarios->temPermissoes('del')) : ?><button class="btn btn-danger btn-sm ml-1"><a class="text-light" href="excluirContato.php?idContato=<?php echo $x->idContato ?>" onclick="return confirm('Você tem certeza disso?')">EXCLUIR</a><?php endif; ?></button>
                </td>




            </tr>
            <?php
        endforeach;
        ?>
                    
    </tbody>


</table>

<?php
include 'inc/footer.inc.php';
?>