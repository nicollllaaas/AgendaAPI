



<?php
include 'classes/usuarios.class.php';
include 'inc/header.inc.php';
session_start();
if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}
$usuarios = new Usuarios();
$usuarios->setUsuario($_SESSION['Logado']);

?>
<h1 style="text-align: center;">Usuarios Admins</h1>
<hr>
<?php if($usuarios->temPermissoes('add')):?><button class="btn btn-success d-grid "><a href="adicionarUsuario.php" class="text-light">ADICIONAR USUARIOS</a></button><?php endif; ?>

<br><br>
<table class="table table-dark table-striped" style="margin-bottom: 250px;">
    <tr>
        <th>id</th>
        <th>Nome</th>
        <th>Email</th>
        <th>Senha</th>
        <th>Permissões</th>
        
              
    </tr>
    <?php
    $lista = $usuarios->listar();
    foreach($lista as $item) :
    ?>
    <tbody>
        <tr>
            <td><?php echo $item['id'];?></td>
            <td><?php echo $item['nome'];?></td>
            <td><?php echo $item['email'];?></td>
            <td><?php echo '*****';?></td>
            <td><?php echo $item['permissoes'];?></td>
               
 
            <td>
               <?php if($usuarios->temPermissoes('super')):?><button class="btn btn-success btn-sm"> <a class="text-light" href="editarUsuario.php?id=<?php echo $item['id'];?>">EDITAR</a><?php endif; ?></button> |

                <?php if($usuarios->temPermissoes('super')):?><button class="btn btn-danger btn-sm"><a class="text-light" href="excluirUsuario.php?id=<?php echo $item['id']?>" onclick="return confirm('Você tem certeza disso?')">EXCLUIR</a><?php endif; ?></button>
            </td>
        </tr>
    </tbody>
    <?php
    endforeach;
    ?>
 
</table>

<?php
    include 'inc/footer.inc.php';
?>

