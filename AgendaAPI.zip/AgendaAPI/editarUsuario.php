<?php
include 'inc/header.inc.php';
include 'classes/usuarios.class.php';
$usuarios = new Usuarios();
session_start();


if (!empty($_GET['id'])) {
    $id = $_GET['id'];
    $info = $usuarios->buscar($id);
    if (empty($info['email'])) {
        header("Location: /AgendaSenac");
        exit;
    }
    $arrayperm = explode(',', $info['permissoes']);
} else {
    header("Location: /AgendaSenac");
    exit;
}
if (!isset($_SESSION['Logado'])) {
    header("Location: login.php");
    exit;
}

?>

<h1 class="text-center">EDITAR USUARIO</h1>
<div class="row justify-content-center">
    <form method="POST" action="editarUsuarioSubmit.php">
        <input type="hidden" name="id" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['id'] ?>" />
        <input type="hidden" name="senha" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['senha'] ?>" />
        Nome: <br>
        <input type="text" name="nome" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['nome'] ?>" /><br><br>
        Email: <br>
        <input type="text" name="email" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['email'] ?>" /><br><br>
        Permissões: <br>
        <label for="add">
            <?php if($usuarios->buscaPermissaoAdd($arrayperm)):?>
            <input type="checkbox" id="add" name="permissoes[]" value="add" checked> Adicionar
            <?php endif; ?>
        </label>  
        <label for="add">
            <?php if(empty($usuarios->buscaPermissaoAdd($arrayperm))):?>
            <input type="checkbox" id="add" name="permissoes[]" value="add" > Adicionar
            <?php endif; ?>
        </label>   
        <label for="edit">
            <?php if($usuarios->buscaPermissaoEdit($arrayperm)):?>
            <input class="ml-3" id="edit" type="checkbox" name="permissoes[]" value="edit" checked> Editar
            <?php endif; ?>
        </label>
        <label for="edit">
            <?php if(empty($usuarios->buscaPermissaoEdit($arrayperm))):?>
            <input class="ml-3" id="edit" type="checkbox" name="permissoes[]" value="edit" > Editar
            <?php endif; ?>
        </label>
        
        <label for="del">
            <?php if($usuarios->buscaPermissaoDel($arrayperm)):?>
            <input class="ml-3" id="del" type="checkbox" name="permissoes[]" value="del" checked > Deletar
            <?php endif; ?>
        </label>
        <label for="del">
            <?php if(empty($usuarios->buscaPermissaoDel($arrayperm))):?>
            <input class="ml-3" id="del" type="checkbox" name="permissoes[]" value="del" > Deletar
            <?php endif; ?>
        </label>
        <label for="super">
            <?php if($usuarios->buscaPermissaoSuper($arrayperm)):?>
            <input class="ml-3" id="super" type="checkbox" name="permissoes[]" value="super" checked> Super 
            <?php endif; ?>
        </label>
        <label for="super">
            <?php if(empty($usuarios->buscaPermissaoSuper($arrayperm))):?>
            <input class="ml-3" id="super" type="checkbox" name="permissoes[]" value="super" > Super 
            <?php endif; ?>
        </label><br><br>


        <input type="submit" class="btn btn-success" name="btCadastrar" value="ALTERAR" />
    </form>
</div>

<?php
include 'inc/footer.inc.php';
?>