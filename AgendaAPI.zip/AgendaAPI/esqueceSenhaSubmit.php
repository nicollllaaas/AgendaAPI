<?php
include 'classes/usuarios.class.php';
$usuarios = new Usuarios();

if(!empty ($_POST['id'])){
    echo 'passou';
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = md5($_POST['senha']);
    $permissoes =  $_POST['permissoes'] ;
    $id = $_POST['id'];
    
    if(!empty($email)){
        $usuarios->editar($nome, $email, $senha, $permissoes, $id);
    }
    header("Location: login.php?status=success");
}

?>  