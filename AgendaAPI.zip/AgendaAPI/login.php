<?php
session_start();
include 'inc/header.inc.php';

    //require_once 'inc/cabecalho.inc.php';
    require 'classes/usuarios.class.php';

    if(!empty($_POST['email'])){
        $email = addslashes($_POST['email']);
        $senha = md5($_POST['senha']);

        $usuarios = new Usuarios();
        if($usuarios->fazerLogin($email, $senha)){
            header("Location: index.php");
            exit;

        }
        else
        {
            echo '<span style="color: red">'."USUARIO E/OU SENHA INCORRETOS".'</span>';
        }
    }
?>
<div class="d-flex justify-content-center align-items-center vh-100" style="margin-bottom: 159px;">
        <div class="custom-div">
            <h1 class="text-center">LOGIN</h1>
            <form method="POST" class="mt-4">
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="senha">Senha:</label>
                    <input type="password" class="form-control" id="senha" name="senha" required>
                </div>
                <div class="text-center">
                    <input type="submit" class="btn btn-light" value="Entrar">
                </div>
                <a href="esqueceSenha2.php" class="text-white">Esqueci minha senha</a>
            </form>
        </div>
    </div>
   

<?php
 include 'inc/footer.inc.php';
?>